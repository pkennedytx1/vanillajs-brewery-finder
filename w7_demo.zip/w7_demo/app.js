// We are using an open API! No key needed!
function getBreweryData() {
    fetch('https://api.openbrewerydb.org/breweries/search?query=dog')
        .then(response => response.json())
        .then(json => console.log(json));
}

getBreweryData();

// Todo: Need to make the getBreweryData function execute on search as well as take in a query and apply it to the request.

// Todo: Display only the frist 10 results in the DOM with basic info.

// BONUS: Put together pagination.